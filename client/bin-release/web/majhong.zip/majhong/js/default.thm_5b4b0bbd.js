window.skins={};
function __extends(d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() {
            this.constructor = d;
        }
    __.prototype = b.prototype;
    d.prototype = new __();
};
window.generateEUI = {};
generateEUI.paths = {};
generateEUI.skins = {"eui.Button":"resource/eui_skins/ButtonSkin.exml","eui.CheckBox":"resource/eui_skins/CheckBoxSkin.exml","eui.HScrollBar":"resource/eui_skins/HScrollBarSkin.exml","eui.HSlider":"resource/eui_skins/HSliderSkin.exml","eui.Panel":"resource/eui_skins/PanelSkin.exml","eui.TextInput":"resource/eui_skins/TextInputSkin.exml","eui.ProgressBar":"resource/eui_skins/ProgressBarSkin.exml","eui.RadioButton":"resource/eui_skins/RadioButtonSkin.exml","eui.Scroller":"resource/eui_skins/ScrollerSkin.exml","eui.ToggleSwitch":"resource/eui_skins/ToggleSwitchSkin.exml","eui.VScrollBar":"resource/eui_skins/VScrollBarSkin.exml","eui.VSlider":"resource/eui_skins/VSliderSkin.exml","eui.ItemRenderer":"resource/eui_skins/ItemRendererSkin.exml"}
generateEUI.paths['resource/eui_main/homeSkin.exml'] = window.homeSkin = (function (_super) {
	__extends(homeSkin, _super);
	function homeSkin() {
		_super.call(this);
		this.skinParts = ["imgBg"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this.imgBg_i()];
	}
	var _proto = homeSkin.prototype;

	_proto.imgBg_i = function () {
		var t = new eui.Image();
		this.imgBg = t;
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.x = 0;
		t.y = 0;
		return t;
	};
	return homeSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ButtonSkin.exml'] = window.skins.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = ButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/CheckBoxSkin.exml'] = window.skins.CheckBoxSkin = (function (_super) {
	__extends(CheckBoxSkin, _super);
	function CheckBoxSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_disabled_png")
				])
		];
	}
	var _proto = CheckBoxSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "checkbox_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return CheckBoxSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HScrollBarSkin.exml'] = window.skins.HScrollBarSkin = (function (_super) {
	__extends(HScrollBarSkin, _super);
	function HScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = HScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 8;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.verticalCenter = 0;
		t.width = 30;
		return t;
	};
	return HScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HSliderSkin.exml'] = window.skins.HSliderSkin = (function (_super) {
	__extends(HSliderSkin, _super);
	function HSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = HSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.height = 6;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_sb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.source = "thumb_png";
		t.verticalCenter = 0;
		return t;
	};
	return HSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ItemRendererSkin.exml'] = window.skins.ItemRendererSkin = (function (_super) {
	__extends(ItemRendererSkin, _super);
	function ItemRendererSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data"],[0],this.labelDisplay,"text")
	}
	var _proto = ItemRendererSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "Tahoma";
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return ItemRendererSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/PanelSkin.exml'] = window.skins.PanelSkin = (function (_super) {
	__extends(PanelSkin, _super);
	function PanelSkin() {
		_super.call(this);
		this.skinParts = ["titleDisplay","moveArea","closeButton"];
		
		this.minHeight = 230;
		this.minWidth = 450;
		this.elementsContent = [this._Image1_i(),this.moveArea_i(),this.closeButton_i()];
	}
	var _proto = PanelSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(2,2,12,12);
		t.source = "border_png";
		t.top = 0;
		return t;
	};
	_proto.moveArea_i = function () {
		var t = new eui.Group();
		this.moveArea = t;
		t.height = 45;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image2_i(),this.titleDisplay_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "header_png";
		t.top = 0;
		return t;
	};
	_proto.titleDisplay_i = function () {
		var t = new eui.Label();
		this.titleDisplay = t;
		t.fontFamily = "Tahoma";
		t.left = 15;
		t.right = 5;
		t.size = 20;
		t.textColor = 0xFFFFFF;
		t.verticalCenter = 0;
		t.wordWrap = false;
		return t;
	};
	_proto.closeButton_i = function () {
		var t = new eui.Button();
		this.closeButton = t;
		t.bottom = 5;
		t.horizontalCenter = 0;
		t.label = "close";
		return t;
	};
	return PanelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ProgressBarSkin.exml'] = window.skins.ProgressBarSkin = (function (_super) {
	__extends(ProgressBarSkin, _super);
	function ProgressBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb","labelDisplay"];
		
		this.minHeight = 18;
		this.minWidth = 30;
		this.elementsContent = [this._Image1_i(),this.thumb_i(),this.labelDisplay_i()];
	}
	var _proto = ProgressBarSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_pb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.percentHeight = 100;
		t.source = "thumb_pb_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.horizontalCenter = 0;
		t.size = 15;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		return t;
	};
	return ProgressBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/RadioButtonSkin.exml'] = window.skins.RadioButtonSkin = (function (_super) {
	__extends(RadioButtonSkin, _super);
	function RadioButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_disabled_png")
				])
		];
	}
	var _proto = RadioButtonSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "radiobutton_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return RadioButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ScrollerSkin.exml'] = window.skins.ScrollerSkin = (function (_super) {
	__extends(ScrollerSkin, _super);
	function ScrollerSkin() {
		_super.call(this);
		this.skinParts = ["horizontalScrollBar","verticalScrollBar"];
		
		this.minHeight = 20;
		this.minWidth = 20;
		this.elementsContent = [this.horizontalScrollBar_i(),this.verticalScrollBar_i()];
	}
	var _proto = ScrollerSkin.prototype;

	_proto.horizontalScrollBar_i = function () {
		var t = new eui.HScrollBar();
		this.horizontalScrollBar = t;
		t.bottom = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.verticalScrollBar_i = function () {
		var t = new eui.VScrollBar();
		this.verticalScrollBar = t;
		t.percentHeight = 100;
		t.right = 0;
		return t;
	};
	return ScrollerSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/TextInputSkin.exml'] = window.skins.TextInputSkin = (function (_super) {
	__extends(TextInputSkin, _super);
	function TextInputSkin() {
		_super.call(this);
		this.skinParts = ["textDisplay","promptDisplay"];
		
		this.minHeight = 40;
		this.minWidth = 300;
		this.elementsContent = [this._Image1_i(),this._Rect1_i(),this.textDisplay_i()];
		this.promptDisplay_i();
		
		this.states = [
			new eui.State ("normal",
				[
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("textDisplay","textColor",0xff0000)
				])
			,
			new eui.State ("normalWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
			,
			new eui.State ("disabledWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
		];
	}
	var _proto = TextInputSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 100;
		t.percentWidth = 100;
		return t;
	};
	_proto.textDisplay_i = function () {
		var t = new eui.EditableText();
		this.textDisplay = t;
		t.height = 24;
		t.left = "10";
		t.right = "10";
		t.size = 20;
		t.textColor = 0x000000;
		t.verticalCenter = "0";
		t.percentWidth = 100;
		return t;
	};
	_proto.promptDisplay_i = function () {
		var t = new eui.Label();
		this.promptDisplay = t;
		t.height = 24;
		t.left = 10;
		t.right = 10;
		t.size = 20;
		t.textColor = 0xa9a9a9;
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	return TextInputSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ToggleSwitchSkin.exml'] = window.skins.ToggleSwitchSkin = (function (_super) {
	__extends(ToggleSwitchSkin, _super);
	function ToggleSwitchSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
		];
	}
	var _proto = ToggleSwitchSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.source = "on_png";
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.horizontalCenter = -18;
		t.source = "handle_png";
		t.verticalCenter = 0;
		return t;
	};
	return ToggleSwitchSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VScrollBarSkin.exml'] = window.skins.VScrollBarSkin = (function (_super) {
	__extends(VScrollBarSkin, _super);
	function VScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 20;
		this.minWidth = 8;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = VScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 30;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.width = 8;
		return t;
	};
	return VScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VSliderSkin.exml'] = window.skins.VSliderSkin = (function (_super) {
	__extends(VSliderSkin, _super);
	function VSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 30;
		this.minWidth = 25;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = VSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_png";
		t.width = 7;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.horizontalCenter = 0;
		t.source = "thumb_png";
		return t;
	};
	return VSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/createRoomSettingSkin.exml'] = window.settingSkin = (function (_super) {
	__extends(settingSkin, _super);
	var settingSkin$Skin1 = 	(function (_super) {
		__extends(settingSkin$Skin1, _super);
		function settingSkin$Skin1() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","cloase_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = settingSkin$Skin1.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "close_png";
			t.verticalCenter = 0;
			return t;
		};
		return settingSkin$Skin1;
	})(eui.Skin);

	var settingSkin$Skin2 = 	(function (_super) {
		__extends(settingSkin$Skin2, _super);
		function settingSkin$Skin2() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = settingSkin$Skin2.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "enterroom-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "确定";
			t.x = 120;
			t.y = 34;
			return t;
		};
		return settingSkin$Skin2;
	})(eui.Skin);

	function settingSkin() {
		_super.call(this);
		this.skinParts = ["_close","radio1_1","radio1_2","radio2_1","radio2_2","radio2_3","radio3_1","radio3_2","radio3_3","radio3_4","radio4_1","radio4_2","_enterRoom"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Label1_i(),this._Label2_i(),this._Label3_i(),this._Label4_i(),this._close_i(),this._Group1_i(),this._Group2_i(),this._Group3_i(),this._Group4_i(),this._enterRoom_i()];
	}
	var _proto = settingSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "dialog-s-top_png";
		t.x = 359;
		t.y = 143;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "dialog-s-bg_png";
		t.x = 376.5;
		t.y = 167;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.size = 20;
		t.text = "房卡模式";
		t.x = 422;
		t.y = 218;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.size = 20;
		t.text = "麻将类型";
		t.x = 422;
		t.y = 273;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.size = 20;
		t.text = "倍数";
		t.x = 462;
		t.y = 364;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.size = 20;
		t.text = "封顶";
		t.x = 462;
		t.y = 462;
		return t;
	};
	_proto._close_i = function () {
		var t = new eui.Button();
		this._close = t;
		t.x = 302.5;
		t.y = 155;
		t.skinName = settingSkin$Skin1;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 52;
		t.width = 456;
		t.x = 524;
		t.y = 206;
		t.elementsContent = [this.radio1_1_i(),this.radio1_2_i()];
		return t;
	};
	_proto.radio1_1_i = function () {
		var t = new eui.RadioButton();
		this.radio1_1 = t;
		t.groupName = "cn1";
		t.label = "AA房卡";
		t.skinName = "skins.RadioButtonSkin";
		t.y = 12;
		return t;
	};
	_proto.radio1_2_i = function () {
		var t = new eui.RadioButton();
		this.radio1_2 = t;
		t.groupName = "cn1";
		t.label = "房主房卡";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 235;
		t.y = 14;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 92;
		t.width = 456;
		t.x = 524;
		t.y = 260;
		t.elementsContent = [this.radio2_1_i(),this.radio2_2_i(),this.radio2_3_i()];
		return t;
	};
	_proto.radio2_1_i = function () {
		var t = new eui.RadioButton();
		this.radio2_1 = t;
		t.groupName = "cn2";
		t.label = "红中发财";
		t.skinName = "skins.RadioButtonSkin";
		t.y = 12;
		return t;
	};
	_proto.radio2_2_i = function () {
		var t = new eui.RadioButton();
		this.radio2_2 = t;
		t.groupName = "cn2";
		t.label = "前痞后赖";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 235;
		t.y = 14;
		return t;
	};
	_proto.radio2_3_i = function () {
		var t = new eui.RadioButton();
		this.radio2_3 = t;
		t.groupName = "cn2";
		t.label = "武汉晃晃";
		t.skinName = "skins.RadioButtonSkin";
		t.x = -1;
		t.y = 54;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 98;
		t.width = 456;
		t.x = 524;
		t.y = 352;
		t.elementsContent = [this.radio3_1_i(),this.radio3_2_i(),this.radio3_3_i(),this.radio3_4_i()];
		return t;
	};
	_proto.radio3_1_i = function () {
		var t = new eui.RadioButton();
		this.radio3_1 = t;
		t.groupName = "cn3";
		t.label = "1倍";
		t.skinName = "skins.RadioButtonSkin";
		t.y = 12;
		return t;
	};
	_proto.radio3_2_i = function () {
		var t = new eui.RadioButton();
		this.radio3_2 = t;
		t.groupName = "cn3";
		t.label = "16倍";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 235;
		t.y = 14;
		return t;
	};
	_proto.radio3_3_i = function () {
		var t = new eui.RadioButton();
		this.radio3_3 = t;
		t.groupName = "cn3";
		t.label = "32倍";
		t.skinName = "skins.RadioButtonSkin";
		t.x = -1;
		t.y = 66;
		return t;
	};
	_proto.radio3_4_i = function () {
		var t = new eui.RadioButton();
		this.radio3_4 = t;
		t.groupName = "cn3";
		t.label = "64倍";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 235;
		t.y = 62;
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 52;
		t.width = 456;
		t.x = 524;
		t.y = 450;
		t.elementsContent = [this.radio4_1_i(),this.radio4_2_i()];
		return t;
	};
	_proto.radio4_1_i = function () {
		var t = new eui.RadioButton();
		this.radio4_1 = t;
		t.groupName = "cn4";
		t.label = "300倍封顶";
		t.skinName = "skins.RadioButtonSkin";
		t.y = 12;
		return t;
	};
	_proto.radio4_2_i = function () {
		var t = new eui.RadioButton();
		this.radio4_2 = t;
		t.groupName = "cn4";
		t.label = "500倍封顶";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 235;
		t.y = 14;
		return t;
	};
	_proto._enterRoom_i = function () {
		var t = new eui.Button();
		this._enterRoom = t;
		t.anchorOffsetX = 166;
		t.anchorOffsetY = 48;
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.x = 697.5;
		t.y = 538;
		t.skinName = settingSkin$Skin2;
		return t;
	};
	return settingSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/dialogMailSkin.exml'] = window.dialogSkin = (function (_super) {
	__extends(dialogSkin, _super);
	var dialogSkin$Skin3 = 	(function (_super) {
		__extends(dialogSkin$Skin3, _super);
		function dialogSkin$Skin3() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin3.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "back-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return dialogSkin$Skin3;
	})(eui.Skin);

	function dialogSkin() {
		_super.call(this);
		this.skinParts = ["_back","_mailContents","_mailScroller"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._back_i(),this._Image5_i(),this._mailScroller_i()];
	}
	var _proto = dialogSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 500;
		t.source = "papper-bg_jpg";
		t.x = 254.02;
		t.y = 134;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 500;
		t.rotation = 180;
		t.scaleY = -1;
		t.source = "papper-bg_jpg";
		t.x = 1066.02;
		t.y = 134;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 500;
		t.rotation = 360;
		t.source = "paper_jpg";
		t.width = 500;
		t.x = 410.02;
		t.y = 134;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "mail-bg_png";
		t.x = 1118;
		t.y = 152;
		return t;
	};
	_proto._back_i = function () {
		var t = new eui.Button();
		this._back = t;
		t.x = 0;
		t.y = 0;
		t.skinName = dialogSkin$Skin3;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "dialog-bg2_png";
		t.x = 0;
		t.y = 186;
		return t;
	};
	_proto._mailScroller_i = function () {
		var t = new eui.Scroller();
		this._mailScroller = t;
		t.height = 470;
		t.width = 770;
		t.x = 275;
		t.y = 148;
		t.viewport = this._mailContents_i();
		return t;
	};
	_proto._mailContents_i = function () {
		var t = new eui.List();
		this._mailContents = t;
		t.height = 131;
		t.x = -209.98;
		t.y = -3;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		return t;
	};
	return dialogSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/dialogShopSkin.exml'] = window.dialogSkin = (function (_super) {
	__extends(dialogSkin, _super);
	var dialogSkin$Skin4 = 	(function (_super) {
		__extends(dialogSkin$Skin4, _super);
		function dialogSkin$Skin4() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin4.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "back-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return dialogSkin$Skin4;
	})(eui.Skin);

	var dialogSkin$Skin5 = 	(function (_super) {
		__extends(dialogSkin$Skin5, _super);
		function dialogSkin$Skin5() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin5.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "dialog-button_png";
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "首充大礼包";
			t.x = 27.36;
			t.y = 16.72;
			return t;
		};
		return dialogSkin$Skin5;
	})(eui.Skin);

	var dialogSkin$Skin6 = 	(function (_super) {
		__extends(dialogSkin$Skin6, _super);
		function dialogSkin$Skin6() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin6.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "dialog-button_png";
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "充值";
			t.x = 72.78;
			t.y = 18.24;
			return t;
		};
		return dialogSkin$Skin6;
	})(eui.Skin);

	var dialogSkin$Skin7 = 	(function (_super) {
		__extends(dialogSkin$Skin7, _super);
		function dialogSkin$Skin7() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin7.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "dialog-button_png";
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "房卡";
			t.x = 71.26;
			t.y = 18.24;
			return t;
		};
		return dialogSkin$Skin7;
	})(eui.Skin);

	var dialogSkin$Skin8 = 	(function (_super) {
		__extends(dialogSkin$Skin8, _super);
		function dialogSkin$Skin8() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin8.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "dialog-button_png";
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "道具";
			t.x = 72.73;
			t.y = 18.24;
			return t;
		};
		return dialogSkin$Skin8;
	})(eui.Skin);

	function dialogSkin() {
		_super.call(this);
		this.skinParts = ["_back","_firstBuy","_addMoney","_addCard","_addTool","_shopContents","_shopScroller"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._Image5_i(),this._Image6_i(),this._Image7_i(),this._Image8_i(),this._back_i(),this._firstBuy_i(),this._addMoney_i(),this._addCard_i(),this._addTool_i(),this._shopScroller_i()];
	}
	var _proto = dialogSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "dialog-left-bg_png";
		t.x = 248;
		t.y = 132;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = -42;
		t.rotation = 179.66;
		t.source = "dialog-left-bg_png";
		t.x = 476;
		t.y = 639.66;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 459;
		t.source = "dialog-right-bg_png";
		t.x = 249.73;
		t.y = 156;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "dialog-bg2_png";
		t.x = 0;
		t.y = 186;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 508;
		t.source = "papper-bg_jpg";
		t.x = 486;
		t.y = 134;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 508;
		t.rotation = 180;
		t.scaleY = -1;
		t.source = "papper-bg_jpg";
		t.x = 1066.09;
		t.y = 134;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 508;
		t.rotation = 360;
		t.source = "paper_jpg";
		t.width = 272;
		t.x = 642;
		t.y = 134;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.source = "shop-bg_png";
		t.x = 1118;
		t.y = 152;
		return t;
	};
	_proto._back_i = function () {
		var t = new eui.Button();
		this._back = t;
		t.x = 0;
		t.y = 0;
		t.skinName = dialogSkin$Skin4;
		return t;
	};
	_proto._firstBuy_i = function () {
		var t = new eui.ToggleButton();
		this._firstBuy = t;
		t.x = 263.77;
		t.y = 170.5;
		t.skinName = dialogSkin$Skin5;
		return t;
	};
	_proto._addMoney_i = function () {
		var t = new eui.ToggleButton();
		this._addMoney = t;
		t.x = 263.77;
		t.y = 265;
		t.skinName = dialogSkin$Skin6;
		return t;
	};
	_proto._addCard_i = function () {
		var t = new eui.ToggleButton();
		this._addCard = t;
		t.x = 263.77;
		t.y = 355;
		t.skinName = dialogSkin$Skin7;
		return t;
	};
	_proto._addTool_i = function () {
		var t = new eui.ToggleButton();
		this._addTool = t;
		t.x = 263.77;
		t.y = 445;
		t.skinName = dialogSkin$Skin8;
		return t;
	};
	_proto._shopScroller_i = function () {
		var t = new eui.Scroller();
		this._shopScroller = t;
		t.height = 473;
		t.width = 560;
		t.x = 506;
		t.y = 152;
		t.viewport = this._shopContents_i();
		return t;
	};
	_proto._shopContents_i = function () {
		var t = new eui.List();
		this._shopContents = t;
		t.height = 131;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		return t;
	};
	return dialogSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/dialogSkin.exml'] = window.dialogSkin = (function (_super) {
	__extends(dialogSkin, _super);
	var dialogSkin$Skin9 = 	(function (_super) {
		__extends(dialogSkin$Skin9, _super);
		function dialogSkin$Skin9() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin9.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "back-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return dialogSkin$Skin9;
	})(eui.Skin);

	function dialogSkin() {
		_super.call(this);
		this.skinParts = ["_back","_mailContents"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._Image5_i(),this._Image6_i(),this._Image7_i(),this._Image8_i(),this._back_i(),this._Scroller1_i()];
	}
	var _proto = dialogSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "dialog-left-bg_png";
		t.x = 248;
		t.y = 132;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = -42;
		t.rotation = 179.66;
		t.source = "dialog-left-bg_png";
		t.x = 476;
		t.y = 639.66;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 459;
		t.source = "dialog-right-bg_png";
		t.x = 249.73;
		t.y = 156;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "dialog-bg2_png";
		t.x = 0;
		t.y = 186;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 508;
		t.source = "papper-bg_jpg";
		t.x = 486;
		t.y = 134;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 508;
		t.rotation = 180;
		t.scaleY = -1;
		t.source = "papper-bg_jpg";
		t.x = 1066.09;
		t.y = 134;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 508;
		t.rotation = 360;
		t.source = "paper_jpg";
		t.width = 272;
		t.x = 642;
		t.y = 134;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.source = "rule-bg_png";
		t.x = 1118;
		t.y = 152;
		return t;
	};
	_proto._back_i = function () {
		var t = new eui.Button();
		this._back = t;
		t.x = 0;
		t.y = 0;
		t.skinName = dialogSkin$Skin9;
		return t;
	};
	_proto._Scroller1_i = function () {
		var t = new eui.Scroller();
		t.height = 473;
		t.width = 560;
		t.x = 506;
		t.y = 152;
		t.viewport = this._mailContents_i();
		return t;
	};
	_proto._mailContents_i = function () {
		var t = new eui.List();
		this._mailContents = t;
		t.height = 131;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		return t;
	};
	return dialogSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/enterRoomSkin.exml'] = window.enterRoomSkin = (function (_super) {
	__extends(enterRoomSkin, _super);
	var enterRoomSkin$Skin10 = 	(function (_super) {
		__extends(enterRoomSkin$Skin10, _super);
		function enterRoomSkin$Skin10() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = enterRoomSkin$Skin10.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "back-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return enterRoomSkin$Skin10;
	})(eui.Skin);

	var enterRoomSkin$Skin11 = 	(function (_super) {
		__extends(enterRoomSkin$Skin11, _super);
		function enterRoomSkin$Skin11() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = enterRoomSkin$Skin11.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "enterroom-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "加入房间";
			t.x = 92;
			t.y = 34;
			return t;
		};
		return enterRoomSkin$Skin11;
	})(eui.Skin);

	function enterRoomSkin() {
		_super.call(this);
		this.skinParts = ["_back","_input","_enterRoom"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._Image5_i(),this._back_i(),this._Label1_i(),this._input_i(),this._enterRoom_i()];
	}
	var _proto = enterRoomSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 508;
		t.source = "papper-bg_jpg";
		t.x = 249.73;
		t.y = 134;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 508;
		t.rotation = 180;
		t.scaleY = -1;
		t.source = "papper-bg_jpg";
		t.x = 1066.09;
		t.y = 134;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 508;
		t.rotation = 360;
		t.source = "paper_jpg";
		t.width = 516;
		t.x = 398;
		t.y = 134;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "enterroom-bg_png";
		t.x = 1118;
		t.y = 152;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "dialog-bg2_png";
		t.x = 0;
		t.y = 186;
		return t;
	};
	_proto._back_i = function () {
		var t = new eui.Button();
		this._back = t;
		t.x = 0;
		t.y = 0;
		t.skinName = enterRoomSkin$Skin10;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.text = "房间号";
		t.x = 405.73;
		t.y = 270;
		return t;
	};
	_proto._input_i = function () {
		var t = new eui.TextInput();
		this._input = t;
		t.x = 517;
		t.y = 265;
		return t;
	};
	_proto._enterRoom_i = function () {
		var t = new eui.Button();
		this._enterRoom = t;
		t.anchorOffsetX = 166;
		t.anchorOffsetY = 48;
		t.x = 683;
		t.y = 387;
		t.skinName = enterRoomSkin$Skin11;
		return t;
	};
	return enterRoomSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/friendIRSkin.exml'] = window.friendIRSkin = (function (_super) {
	__extends(friendIRSkin, _super);
	function friendIRSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 86;
		this.elementsContent = [this._Image1_i(),this._Label1_i(),this._Label2_i(),this._Image2_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data.name"],[0],this._Label1,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.count"],[0],this._Label2,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.icon"],[0],this._Image2,"source")
	}
	var _proto = friendIRSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 86;
		t.source = "chat-bg-2_png";
		t.width = 315;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		this._Label1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.textAlign = "left";
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 83;
		t.y = 13;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		this._Label2 = t;
		t.fontFamily = "微软雅黑";
		t.size = 20;
		t.textAlign = "left";
		t.verticalAlign = "middle";
		t.width = 220;
		t.x = 83;
		t.y = 44;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 61;
		t.width = 67;
		t.x = 10;
		t.y = 9;
		return t;
	};
	return friendIRSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/gameHistoryIRSkin.exml'] = window.friendIRSkin = (function (_super) {
	__extends(friendIRSkin, _super);
	function friendIRSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Label1_i(),this._Label2_i(),this._Label3_i(),this._Label4_i(),this._Label5_i(),this._Label6_i(),this._Label7_i(),this._Label8_i(),this._Label9_i(),this._Label10_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data.roomId"],[0],this._Label2,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.roomOwner"],[0],this._Label4,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.gameCount"],[0],this._Label6,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.gameDuration"],[0],this._Label8,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.overTime"],[0],this._Label9,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.record"],[0],this._Label10,"text")
	}
	var _proto = friendIRSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 127;
		t.scale9Grid = new egret.Rectangle(70,40,10,40);
		t.source = "mailItem-bg_png";
		t.width = 770;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.text = "房号:";
		t.textAlign = "left";
		t.textColor = 0xa58e6f;
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 100;
		t.y = 16.5;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		this._Label2 = t;
		t.fontFamily = "微软雅黑";
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x841907;
		t.verticalAlign = "middle";
		t.width = 220;
		t.x = 150;
		t.y = 19.5;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.text = "房主:";
		t.textAlign = "left";
		t.textColor = 0xa58e6f;
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 320;
		t.y = 16.5;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		this._Label4 = t;
		t.fontFamily = "微软雅黑";
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x841907;
		t.verticalAlign = "middle";
		t.width = 220;
		t.x = 370;
		t.y = 19.5;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.text = "局数:";
		t.textAlign = "left";
		t.textColor = 0xa58e6f;
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 100;
		t.y = 52;
		return t;
	};
	_proto._Label6_i = function () {
		var t = new eui.Label();
		this._Label6 = t;
		t.fontFamily = "微软雅黑";
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x841907;
		t.verticalAlign = "middle";
		t.width = 220;
		t.x = 150;
		t.y = 54;
		return t;
	};
	_proto._Label7_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.text = "时间:";
		t.textAlign = "left";
		t.textColor = 0xa58e6f;
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 320;
		t.y = 52;
		return t;
	};
	_proto._Label8_i = function () {
		var t = new eui.Label();
		this._Label8 = t;
		t.fontFamily = "微软雅黑";
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x841907;
		t.verticalAlign = "middle";
		t.width = 220;
		t.x = 370;
		t.y = 54;
		return t;
	};
	_proto._Label9_i = function () {
		var t = new eui.Label();
		this._Label9 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x841907;
		t.verticalAlign = "middle";
		t.width = 300;
		t.x = 100;
		t.y = 88;
		return t;
	};
	_proto._Label10_i = function () {
		var t = new eui.Label();
		this._Label10 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x841907;
		t.verticalAlign = "middle";
		t.width = 100;
		t.x = 596.5;
		t.y = 52;
		return t;
	};
	return friendIRSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/gamehistorySkin.exml'] = window.dialogSkin = (function (_super) {
	__extends(dialogSkin, _super);
	var dialogSkin$Skin12 = 	(function (_super) {
		__extends(dialogSkin$Skin12, _super);
		function dialogSkin$Skin12() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin12.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "back-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return dialogSkin$Skin12;
	})(eui.Skin);

	function dialogSkin() {
		_super.call(this);
		this.skinParts = ["_back","_gameHistory","_gameHistoryScroller"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._back_i(),this._Image5_i(),this._gameHistoryScroller_i()];
	}
	var _proto = dialogSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 500;
		t.source = "papper-bg_jpg";
		t.x = 254.02;
		t.y = 134;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 500;
		t.rotation = 180;
		t.scaleY = -1;
		t.source = "papper-bg_jpg";
		t.x = 1066.02;
		t.y = 134;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 500;
		t.rotation = 360;
		t.source = "paper_jpg";
		t.width = 500;
		t.x = 410.02;
		t.y = 134;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "gameHistory-bg_png";
		t.x = 1118;
		t.y = 152;
		return t;
	};
	_proto._back_i = function () {
		var t = new eui.Button();
		this._back = t;
		t.x = 0;
		t.y = 0;
		t.skinName = dialogSkin$Skin12;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "dialog-bg2_png";
		t.x = 0;
		t.y = 186;
		return t;
	};
	_proto._gameHistoryScroller_i = function () {
		var t = new eui.Scroller();
		this._gameHistoryScroller = t;
		t.height = 470;
		t.width = 770;
		t.x = 275;
		t.y = 148;
		t.viewport = this._gameHistory_i();
		return t;
	};
	_proto._gameHistory_i = function () {
		var t = new eui.List();
		this._gameHistory = t;
		t.height = 131;
		t.x = -209.98;
		t.y = -3;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		return t;
	};
	return dialogSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/headSkin.exml'] = window.headSkin = (function (_super) {
	__extends(headSkin, _super);
	var headSkin$Skin13 = 	(function (_super) {
		__extends(headSkin$Skin13, _super);
		function headSkin$Skin13() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","plus-b-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = headSkin$Skin13.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "plus-b_png";
			t.verticalCenter = 0;
			return t;
		};
		return headSkin$Skin13;
	})(eui.Skin);

	var headSkin$Skin14 = 	(function (_super) {
		__extends(headSkin$Skin14, _super);
		function headSkin$Skin14() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","plus-b-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = headSkin$Skin14.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "plus-b_png";
			t.verticalCenter = 0;
			return t;
		};
		return headSkin$Skin14;
	})(eui.Skin);

	var headSkin$Skin15 = 	(function (_super) {
		__extends(headSkin$Skin15, _super);
		function headSkin$Skin15() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","plus-b-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = headSkin$Skin15.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "plus-b_png";
			t.verticalCenter = 0;
			return t;
		};
		return headSkin$Skin15;
	})(eui.Skin);

	function headSkin() {
		_super.call(this);
		this.skinParts = ["_addTool","_addMoney","_addCard"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._addTool_i(),this._addMoney_i(),this._addCard_i(),this._Label1_i(),this._Label2_i(),this._Label3_i(),this._Label4_i(),this._Label5_i()];
	}
	var _proto = headSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "damon-i_png";
		t.x = 736;
		t.y = 14;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "head-i_png";
		t.x = 54;
		t.y = 6;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "room-card-bg_png";
		t.x = 1038;
		t.y = 6;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "jifen-bg_png";
		t.x = 424;
		t.y = 12;
		return t;
	};
	_proto._addTool_i = function () {
		var t = new eui.Button();
		this._addTool = t;
		t.x = 939;
		t.y = 16;
		t.skinName = headSkin$Skin13;
		return t;
	};
	_proto._addMoney_i = function () {
		var t = new eui.Button();
		this._addMoney = t;
		t.x = 631;
		t.y = 16;
		t.skinName = headSkin$Skin14;
		return t;
	};
	_proto._addCard_i = function () {
		var t = new eui.Button();
		this._addCard = t;
		t.x = 1245;
		t.y = 16;
		t.skinName = headSkin$Skin15;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.text = "Label";
		t.x = 162.5;
		t.y = 18;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.text = "Label";
		t.x = 162.5;
		t.y = 48;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.text = "Label";
		t.x = 510.5;
		t.y = 32;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.text = "Label";
		t.x = 821;
		t.y = 32;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.text = "Label";
		t.x = 1126.5;
		t.y = 32;
		return t;
	};
	return headSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/mailContentIRSkin.exml'] = window.friendIRSkin = (function (_super) {
	__extends(friendIRSkin, _super);
	function friendIRSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Label1_i(),this._Label2_i(),this._Label3_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data.mailIcon"],[0],this._Image2,"source")
		eui.Binding.$bindProperties(this, ["hostComponent.data.mailInfo"],[0],this._Label1,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.remainTime"],[0],this._Label2,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.textColor"],[0],this._Label2,"textColor")
		eui.Binding.$bindProperties(this, ["hostComponent.data.date"],[0],this._Label3,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.textColor"],[0],this._Label3,"textColor")
	}
	var _proto = friendIRSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 127;
		t.scale9Grid = new egret.Rectangle(70,40,10,40);
		t.source = "mailItem-bg_png";
		t.width = 770;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.x = 54.5;
		t.y = 13.5;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		this._Label1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x831A05;
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 152.5;
		t.y = 52;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		this._Label2 = t;
		t.fontFamily = "微软雅黑";
		t.size = 20;
		t.textAlign = "right";
		t.verticalAlign = "middle";
		t.width = 220;
		t.x = 494;
		t.y = 39.5;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		this._Label3 = t;
		t.fontFamily = "微软雅黑";
		t.size = 20;
		t.textAlign = "right";
		t.verticalAlign = "middle";
		t.width = 220;
		t.x = 494;
		t.y = 69.5;
		return t;
	};
	return friendIRSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/mainSkin.exml'] = window.mainSkin = (function (_super) {
	__extends(mainSkin, _super);
	var mainSkin$Skin16 = 	(function (_super) {
		__extends(mainSkin$Skin16, _super);
		function mainSkin$Skin16() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","enter-b-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin16.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "enter-b_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin16;
	})(eui.Skin);

	var mainSkin$Skin17 = 	(function (_super) {
		__extends(mainSkin$Skin17, _super);
		function mainSkin$Skin17() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","create-room-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin17.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "create-room-i_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin17;
	})(eui.Skin);

	var mainSkin$Skin18 = 	(function (_super) {
		__extends(mainSkin$Skin18, _super);
		function mainSkin$Skin18() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","my-b-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin18.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "my-b_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin18;
	})(eui.Skin);

	var mainSkin$Skin19 = 	(function (_super) {
		__extends(mainSkin$Skin19, _super);
		function mainSkin$Skin19() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","my-i-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin19.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "my-i_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin19;
	})(eui.Skin);

	var mainSkin$Skin20 = 	(function (_super) {
		__extends(mainSkin$Skin20, _super);
		function mainSkin$Skin20() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","tools-i-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin20.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "tools-i_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin20;
	})(eui.Skin);

	var mainSkin$Skin21 = 	(function (_super) {
		__extends(mainSkin$Skin21, _super);
		function mainSkin$Skin21() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","zhanji-i-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin21.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "zhanji-i_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin21;
	})(eui.Skin);

	var mainSkin$Skin22 = 	(function (_super) {
		__extends(mainSkin$Skin22, _super);
		function mainSkin$Skin22() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","news-i-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin22.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "news-i_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin22;
	})(eui.Skin);

	var mainSkin$Skin23 = 	(function (_super) {
		__extends(mainSkin$Skin23, _super);
		function mainSkin$Skin23() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","play-i-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin23.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "play-i_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin23;
	})(eui.Skin);

	var mainSkin$Skin24 = 	(function (_super) {
		__extends(mainSkin$Skin24, _super);
		function mainSkin$Skin24() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","setting-i-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainSkin$Skin24.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "setting-i_png";
			t.verticalCenter = 0;
			return t;
		};
		return mainSkin$Skin24;
	})(eui.Skin);

	function mainSkin() {
		_super.call(this);
		this.skinParts = ["enterRoom","createRoom","myRoom","_myI","_toolsI","_zhanjiI","_newsI","_playI","_setI","listFriend","scrListFriend"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this.enterRoom_i(),this.createRoom_i(),this.myRoom_i(),this._myI_i(),this._toolsI_i(),this._zhanjiI_i(),this._newsI_i(),this._playI_i(),this._setI_i(),this.scrListFriend_i()];
	}
	var _proto = mainSkin.prototype;

	_proto.enterRoom_i = function () {
		var t = new eui.Button();
		this.enterRoom = t;
		t.x = 879;
		t.y = 174;
		t.skinName = mainSkin$Skin16;
		return t;
	};
	_proto.createRoom_i = function () {
		var t = new eui.Button();
		this.createRoom = t;
		t.x = 879;
		t.y = 313;
		t.skinName = mainSkin$Skin17;
		return t;
	};
	_proto.myRoom_i = function () {
		var t = new eui.Button();
		this.myRoom = t;
		t.x = 879;
		t.y = 454;
		t.skinName = mainSkin$Skin18;
		return t;
	};
	_proto._myI_i = function () {
		var t = new eui.Button();
		this._myI = t;
		t.x = 197;
		t.y = 583;
		t.skinName = mainSkin$Skin19;
		return t;
	};
	_proto._toolsI_i = function () {
		var t = new eui.Button();
		this._toolsI = t;
		t.x = 371;
		t.y = 583;
		t.skinName = mainSkin$Skin20;
		return t;
	};
	_proto._zhanjiI_i = function () {
		var t = new eui.Button();
		this._zhanjiI = t;
		t.x = 552;
		t.y = 583;
		t.skinName = mainSkin$Skin21;
		return t;
	};
	_proto._newsI_i = function () {
		var t = new eui.Button();
		this._newsI = t;
		t.x = 715;
		t.y = 583;
		t.skinName = mainSkin$Skin22;
		return t;
	};
	_proto._playI_i = function () {
		var t = new eui.Button();
		this._playI = t;
		t.x = 879;
		t.y = 583;
		t.skinName = mainSkin$Skin23;
		return t;
	};
	_proto._setI_i = function () {
		var t = new eui.Button();
		this._setI = t;
		t.x = 1036;
		t.y = 583;
		t.skinName = mainSkin$Skin24;
		return t;
	};
	_proto.scrListFriend_i = function () {
		var t = new eui.Scroller();
		this.scrListFriend = t;
		t.height = 415;
		t.width = 317;
		t.x = 120;
		t.y = 150;
		t.viewport = this.listFriend_i();
		return t;
	};
	_proto.listFriend_i = function () {
		var t = new eui.List();
		this.listFriend = t;
		t.height = 92;
		t.width = 315;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		return t;
	};
	return mainSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/myRoomIRSkin.exml'] = window.friendIRSkin = (function (_super) {
	__extends(friendIRSkin, _super);
	function friendIRSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Label1_i(),this._Label2_i(),this._Image3_i(),this._Image4_i(),this._Image5_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data.roomId"],[0],this._Label2,"text")
	}
	var _proto = friendIRSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 127;
		t.scale9Grid = new egret.Rectangle(70,40,10,40);
		t.source = "mailItem-bg_png";
		t.width = 547;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "free-seat_jpg";
		t.x = 172.5;
		t.y = 29;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.text = "房间号";
		t.textAlign = "left";
		t.textColor = 0xa58e6f;
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 80;
		t.y = 33;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		this._Label2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x841907;
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 80;
		t.y = 62;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "free-seat_jpg";
		t.x = 252;
		t.y = 28.5;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "free-seat_jpg";
		t.x = 332;
		t.y = 29;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "free-seat_jpg";
		t.x = 412;
		t.y = 29;
		return t;
	};
	return friendIRSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/myRoomSkin.exml'] = window.dialogSkin = (function (_super) {
	__extends(dialogSkin, _super);
	var dialogSkin$Skin25 = 	(function (_super) {
		__extends(dialogSkin$Skin25, _super);
		function dialogSkin$Skin25() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin25.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "back-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return dialogSkin$Skin25;
	})(eui.Skin);

	var dialogSkin$Skin26 = 	(function (_super) {
		__extends(dialogSkin$Skin26, _super);
		function dialogSkin$Skin26() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin26.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "dialog-button_png";
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "游戏中···";
			t.x = 42.5;
			t.y = 20.06;
			return t;
		};
		return dialogSkin$Skin26;
	})(eui.Skin);

	var dialogSkin$Skin27 = 	(function (_super) {
		__extends(dialogSkin$Skin27, _super);
		function dialogSkin$Skin27() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = dialogSkin$Skin27.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "dialog-button_png";
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "可用房间";
			t.textAlign = "left";
			t.x = 42.5;
			t.y = 19.77;
			return t;
		};
		return dialogSkin$Skin27;
	})(eui.Skin);

	function dialogSkin() {
		_super.call(this);
		this.skinParts = ["_back","_busyRoom","_freeRoom","_myRooms","_roomScroller"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._Image5_i(),this._Image6_i(),this._Image7_i(),this._Image8_i(),this._back_i(),this._busyRoom_i(),this._freeRoom_i(),this._roomScroller_i()];
	}
	var _proto = dialogSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "dialog-left-bg_png";
		t.x = 248;
		t.y = 132;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = -42;
		t.rotation = 179.66;
		t.source = "dialog-left-bg_png";
		t.x = 476;
		t.y = 639.66;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 459;
		t.source = "dialog-right-bg_png";
		t.x = 249.73;
		t.y = 156;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "dialog-bg2_png";
		t.x = 0;
		t.y = 186;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 508;
		t.source = "papper-bg_jpg";
		t.x = 486;
		t.y = 134;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 508;
		t.rotation = 180;
		t.scaleY = -1;
		t.source = "papper-bg_jpg";
		t.x = 1066.09;
		t.y = 134;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 508;
		t.rotation = 360;
		t.source = "paper_jpg";
		t.width = 272;
		t.x = 642;
		t.y = 134;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.source = "myRoom-bg_png";
		t.x = 1118;
		t.y = 152;
		return t;
	};
	_proto._back_i = function () {
		var t = new eui.Button();
		this._back = t;
		t.x = 0;
		t.y = 0;
		t.skinName = dialogSkin$Skin25;
		return t;
	};
	_proto._busyRoom_i = function () {
		var t = new eui.ToggleButton();
		this._busyRoom = t;
		t.x = 263.77;
		t.y = 170.5;
		t.skinName = dialogSkin$Skin26;
		return t;
	};
	_proto._freeRoom_i = function () {
		var t = new eui.ToggleButton();
		this._freeRoom = t;
		t.x = 263.77;
		t.y = 265;
		t.skinName = dialogSkin$Skin27;
		return t;
	};
	_proto._roomScroller_i = function () {
		var t = new eui.Scroller();
		this._roomScroller = t;
		t.height = 473;
		t.width = 560;
		t.x = 506;
		t.y = 152;
		t.viewport = this._myRooms_i();
		return t;
	};
	_proto._myRooms_i = function () {
		var t = new eui.List();
		this._myRooms = t;
		t.height = 131;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		return t;
	};
	return dialogSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/settingSkin.exml'] = window.settingSkin = (function (_super) {
	__extends(settingSkin, _super);
	var settingSkin$Skin28 = 	(function (_super) {
		__extends(settingSkin$Skin28, _super);
		function settingSkin$Skin28() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","cloase_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = settingSkin$Skin28.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "close_png";
			t.verticalCenter = 0;
			return t;
		};
		return settingSkin$Skin28;
	})(eui.Skin);

	var settingSkin$Skin29 = 	(function (_super) {
		__extends(settingSkin$Skin29, _super);
		function settingSkin$Skin29() {
			_super.call(this);
			this.skinParts = [];
			
			this.currentState = "up";
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = settingSkin$Skin29.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "dialog-button_png";
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.fontFamily = "微软雅黑";
			t.percentHeight = 90;
			t.size = 20;
			t.text = "确定";
			t.textAlign = "center";
			t.textColor = 0xffffff;
			t.verticalAlign = "middle";
			t.percentWidth = 100;
			return t;
		};
		return settingSkin$Skin29;
	})(eui.Skin);

	function settingSkin() {
		_super.call(this);
		this.skinParts = ["_close","_bgmOpen","_bgmClose","_effectOpen","_effectClose","_confirmSetting"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._close_i(),this._Group1_i(),this._Group2_i(),this._confirmSetting_i()];
	}
	var _proto = settingSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "dialog-s-top_png";
		t.x = 359;
		t.y = 143;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "dialog-s-bg_png";
		t.x = 376.5;
		t.y = 167;
		return t;
	};
	_proto._close_i = function () {
		var t = new eui.Button();
		this._close = t;
		t.x = 302.5;
		t.y = 155;
		t.skinName = settingSkin$Skin28;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 52;
		t.width = 456;
		t.x = 454;
		t.y = 216;
		t.elementsContent = [this._Label1_i(),this._bgmOpen_i(),this._bgmClose_i()];
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.text = "音乐";
		t.x = 30;
		t.y = 8;
		return t;
	};
	_proto._bgmOpen_i = function () {
		var t = new eui.RadioButton();
		this._bgmOpen = t;
		t.groupName = "cn1";
		t.label = "开";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 132;
		t.y = 12;
		return t;
	};
	_proto._bgmClose_i = function () {
		var t = new eui.RadioButton();
		this._bgmClose = t;
		t.groupName = "cn1";
		t.label = "关";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 323;
		t.y = 14;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 52;
		t.width = 456;
		t.x = 454;
		t.y = 272;
		t.elementsContent = [this._Label2_i(),this._effectOpen_i(),this._effectClose_i()];
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.text = "音效";
		t.x = 30;
		t.y = 10;
		return t;
	};
	_proto._effectOpen_i = function () {
		var t = new eui.RadioButton();
		this._effectOpen = t;
		t.groupName = "cn2";
		t.label = "开";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 132;
		t.y = 12;
		return t;
	};
	_proto._effectClose_i = function () {
		var t = new eui.RadioButton();
		this._effectClose = t;
		t.groupName = "cn2";
		t.label = "关";
		t.skinName = "skins.RadioButtonSkin";
		t.x = 323;
		t.y = 14;
		return t;
	};
	_proto._confirmSetting_i = function () {
		var t = new eui.Button();
		this._confirmSetting = t;
		t.x = 586.5;
		t.y = 414;
		t.skinName = settingSkin$Skin29;
		return t;
	};
	return settingSkin;
})(eui.Skin);generateEUI.paths['resource/eui_main/skins/shopContentIRSkin.exml'] = window.friendIRSkin = (function (_super) {
	__extends(friendIRSkin, _super);
	var friendIRSkin$Skin30 = 	(function (_super) {
		__extends(friendIRSkin$Skin30, _super);
		function friendIRSkin$Skin30() {
			_super.call(this);
			this.skinParts = [];
			
			this.currentState = "up";
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = friendIRSkin$Skin30.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "dialog-button_png";
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.fontFamily = "微软雅黑";
			t.percentHeight = 90;
			t.size = 20;
			t.text = "";
			t.textAlign = "center";
			t.textColor = 0xffffff;
			t.verticalAlign = "middle";
			t.percentWidth = 100;
			return t;
		};
		return friendIRSkin$Skin30;
	})(eui.Skin);

	function friendIRSkin() {
		_super.call(this);
		this.skinParts = ["_price","_buyTool"];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Label1_i(),this._Label2_i(),this._price_i(),this._buyTool_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data.purpose"],[0],this._Label1,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.desc"],[0],this._Label2,"text")
		eui.Binding.$bindProperties(this, ["hostComponent.data.price"],[0],this._price,"text")
	}
	var _proto = friendIRSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 127;
		t.scale9Grid = new egret.Rectangle(70,40,50,40);
		t.source = "shopContent-bg_png";
		t.width = 550;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "shopContent-icon_png";
		t.x = 55;
		t.y = 5;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		this._Label1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x92785D;
		t.verticalAlign = "middle";
		t.width = 191;
		t.x = 170;
		t.y = 28;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		this._Label2 = t;
		t.fontFamily = "微软雅黑";
		t.size = 20;
		t.textAlign = "left";
		t.textColor = 0x831A04;
		t.verticalAlign = "middle";
		t.width = 220;
		t.x = 170;
		t.y = 68;
		return t;
	};
	_proto._price_i = function () {
		var t = new eui.Label();
		this._price = t;
		t.fontFamily = "微软雅黑";
		t.visible = false;
		return t;
	};
	_proto._buyTool_i = function () {
		var t = new eui.Button();
		this._buyTool = t;
		t.x = 337.77;
		t.y = 28;
		t.skinName = friendIRSkin$Skin30;
		return t;
	};
	return friendIRSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/cardIRSkin.exml'] = window.cardIRSkin = (function (_super) {
	__extends(cardIRSkin, _super);
	function cardIRSkin() {
		_super.call(this);
		this.skinParts = ["_bg","_cardBg","_joker"];
		
		this.elementsContent = [this._bg_i(),this._cardBg_i(),this._joker_i()];
	}
	var _proto = cardIRSkin.prototype;

	_proto._bg_i = function () {
		var t = new eui.Image();
		this._bg = t;
		return t;
	};
	_proto._cardBg_i = function () {
		var t = new eui.Image();
		this._cardBg = t;
		return t;
	};
	_proto._joker_i = function () {
		var t = new eui.Image();
		this._joker = t;
		return t;
	};
	return cardIRSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/chatDeListIRSkin.exml'] = window.chatDeListSkin = (function (_super) {
	__extends(chatDeListSkin, _super);
	function chatDeListSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 300;
		this.width = 400;
	}
	var _proto = chatDeListSkin.prototype;

	return chatDeListSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/chatDeListSkin.exml'] = window.chatDeListSkin = (function (_super) {
	__extends(chatDeListSkin, _super);
	function chatDeListSkin() {
		_super.call(this);
		this.skinParts = ["listChat","scrDeListChat"];
		
		this.height = 300;
		this.width = 400;
		this.elementsContent = [this.scrDeListChat_i()];
	}
	var _proto = chatDeListSkin.prototype;

	_proto.scrDeListChat_i = function () {
		var t = new eui.Scroller();
		this.scrDeListChat = t;
		t.height = 532;
		t.width = 746;
		t.y = 90;
		t.viewport = this.listChat_i();
		return t;
	};
	_proto.listChat_i = function () {
		var t = new eui.List();
		this.listChat = t;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		return t;
	};
	return chatDeListSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/chatExListSkin.exml'] = window.chatExListSkin = (function (_super) {
	__extends(chatExListSkin, _super);
	function chatExListSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 617;
		this.width = 746;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._Image5_i(),this._Image6_i(),this._Image7_i(),this._Image8_i(),this._Image9_i(),this._Image10_i(),this._Image11_i(),this._Image12_i(),this._Image13_i(),this._Image14_i()];
	}
	var _proto = chatExListSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "e1_png";
		t.x = 54;
		t.y = 137.5;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "e2_png";
		t.x = 188;
		t.y = 137.5;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "e3_png";
		t.x = 321;
		t.y = 137.5;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.source = "e4_png";
		t.x = 455;
		t.y = 137.5;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.source = "e5_png";
		t.x = 588;
		t.y = 137.5;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.source = "e6_png";
		t.x = 54;
		t.y = 235.5;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.source = "e7_png";
		t.x = 188;
		t.y = 235.5;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.source = "e8_png";
		t.x = 321;
		t.y = 235.5;
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.source = "e9_png";
		t.x = 455;
		t.y = 235.5;
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.source = "e10_png";
		t.x = 588;
		t.y = 235.5;
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.source = "e11_png";
		t.x = 54;
		t.y = 333.5;
		return t;
	};
	_proto._Image12_i = function () {
		var t = new eui.Image();
		t.source = "e12_png";
		t.x = 188;
		t.y = 333.5;
		return t;
	};
	_proto._Image13_i = function () {
		var t = new eui.Image();
		t.source = "e13_png";
		t.x = 321;
		t.y = 333.5;
		return t;
	};
	_proto._Image14_i = function () {
		var t = new eui.Image();
		t.source = "e14_png";
		t.x = 455;
		t.y = 333.5;
		return t;
	};
	return chatExListSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/chatListSkin.exml'] = window.chatListSkin = (function (_super) {
	__extends(chatListSkin, _super);
	function chatListSkin() {
		_super.call(this);
		this.skinParts = ["listChat","scrListChat"];
		
		this.height = 617;
		this.width = 746;
		this.elementsContent = [this.scrListChat_i()];
	}
	var _proto = chatListSkin.prototype;

	_proto.scrListChat_i = function () {
		var t = new eui.Scroller();
		this.scrListChat = t;
		t.height = 532;
		t.width = 746;
		t.y = 90;
		t.viewport = this.listChat_i();
		return t;
	};
	_proto.listChat_i = function () {
		var t = new eui.List();
		this.listChat = t;
		t.layout = this._VerticalLayout1_i();
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		return t;
	};
	return chatListSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/chatSkin.exml'] = window.chatSkin = (function (_super) {
	__extends(chatSkin, _super);
	var chatSkin$Skin31 = 	(function (_super) {
		__extends(chatSkin$Skin31, _super);
		function chatSkin$Skin31() {
			_super.call(this);
			this.skinParts = [];
			
			this.minHeight = 50;
			this.minWidth = 100;
			this.elementsContent = [this._Image1_i(),this._Image2_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","chat-btn-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
				,
				new eui.State ("disabledAndSelected",
					[
						new eui.SetProperty("_Image1","source","mbtn_BgFc_png")
					])
			];
		}
		var _proto = chatSkin$Skin31.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "chat-btn_png";
			return t;
		};
		_proto._Image2_i = function () {
			var t = new eui.Image();
			t.source = "expression-i1_png";
			t.x = 68;
			t.y = 16;
			return t;
		};
		return chatSkin$Skin31;
	})(eui.Skin);

	var chatSkin$Skin32 = 	(function (_super) {
		__extends(chatSkin$Skin32, _super);
		function chatSkin$Skin32() {
			_super.call(this);
			this.skinParts = [];
			
			this.minHeight = 50;
			this.minWidth = 100;
			this.elementsContent = [this._Image1_i(),this._Image2_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","chat-btn-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
				,
				new eui.State ("disabledAndSelected",
					[
						new eui.SetProperty("_Image1","source","chat-btn_png")
					])
			];
		}
		var _proto = chatSkin$Skin32.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "chat-btn_png";
			return t;
		};
		_proto._Image2_i = function () {
			var t = new eui.Image();
			t.source = "expression-i2_png";
			t.x = 38;
			t.y = 18;
			return t;
		};
		return chatSkin$Skin32;
	})(eui.Skin);

	var chatSkin$Skin33 = 	(function (_super) {
		__extends(chatSkin$Skin33, _super);
		function chatSkin$Skin33() {
			_super.call(this);
			this.skinParts = [];
			
			this.minHeight = 50;
			this.minWidth = 100;
			this.elementsContent = [this._Image1_i(),this._Image2_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","chat-btn-down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
				,
				new eui.State ("disabledAndSelected",
					[
						new eui.SetProperty("_Image1","source","chat-btn_png")
					])
			];
		}
		var _proto = chatSkin$Skin33.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "chat-btn_png";
			return t;
		};
		_proto._Image2_i = function () {
			var t = new eui.Image();
			t.source = "expression-i3_png";
			t.x = 34;
			t.y = 14;
			return t;
		};
		return chatSkin$Skin33;
	})(eui.Skin);

	var chatSkin$Skin34 = 	(function (_super) {
		__extends(chatSkin$Skin34, _super);
		function chatSkin$Skin34() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = chatSkin$Skin34.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "dialog-button_png";
			t.verticalCenter = 0;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "发送";
			t.x = 72;
			t.y = 20;
			return t;
		};
		return chatSkin$Skin34;
	})(eui.Skin);

	var chatSkin$Skin35 = 	(function (_super) {
		__extends(chatSkin$Skin35, _super);
		function chatSkin$Skin35() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","dialog-button-select_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = chatSkin$Skin35.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "dialog-button_png";
			t.verticalCenter = 0;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "录音";
			t.x = 72;
			t.y = 20;
			return t;
		};
		return chatSkin$Skin35;
	})(eui.Skin);

	function chatSkin() {
		_super.call(this);
		this.skinParts = ["_biaoqing","_quickchat","_chatlist","_textInupt","_send","_record"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._biaoqing_i(),this._quickchat_i(),this._chatlist_i(),this._textInupt_i(),this._send_i(),this._record_i()];
	}
	var _proto = chatSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "chat-bg2_png";
		t.x = 0;
		t.y = 10;
		return t;
	};
	_proto._biaoqing_i = function () {
		var t = new eui.ToggleButton();
		this._biaoqing = t;
		t.x = 0;
		t.y = 10;
		t.skinName = chatSkin$Skin31;
		return t;
	};
	_proto._quickchat_i = function () {
		var t = new eui.ToggleButton();
		this._quickchat = t;
		t.x = 250;
		t.y = 10;
		t.skinName = chatSkin$Skin32;
		return t;
	};
	_proto._chatlist_i = function () {
		var t = new eui.ToggleButton();
		this._chatlist = t;
		t.x = 500;
		t.y = 10;
		t.skinName = chatSkin$Skin33;
		return t;
	};
	_proto._textInupt_i = function () {
		var t = new eui.TextInput();
		this._textInupt = t;
		t.alpha = 0;
		t.anchorOffsetX = 0;
		t.width = 479;
		t.x = 27;
		t.y = 657.5;
		return t;
	};
	_proto._send_i = function () {
		var t = new eui.Button();
		this._send = t;
		t.anchorOffsetX = 29;
		t.anchorOffsetY = 44;
		t.scaleX = 0.45;
		t.x = 672.8;
		t.y = 684;
		t.skinName = chatSkin$Skin34;
		return t;
	};
	_proto._record_i = function () {
		var t = new eui.Button();
		this._record = t;
		t.anchorOffsetX = 171.7;
		t.anchorOffsetY = 38;
		t.scaleX = 0.62;
		t.x = 631.45;
		t.y = 678;
		t.skinName = chatSkin$Skin35;
		return t;
	};
	return chatSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/chatlistIRSkin.exml'] = window.chatlistIRSkin = (function (_super) {
	__extends(chatlistIRSkin, _super);
	function chatlistIRSkin() {
		_super.call(this);
		this.skinParts = ["chatBg","chatLabel"];
		
		this.elementsContent = [this._Image1_i(),this.chatBg_i(),this.chatLabel_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data.icon"],[0],this._Image1,"source")
		eui.Binding.$bindProperties(this, ["hostComponent.data.count"],[0],this.chatLabel,"text")
	}
	var _proto = chatlistIRSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.chatBg_i = function () {
		var t = new eui.Image();
		this.chatBg = t;
		t.fillMode = "scale";
		t.height = 60;
		t.scale9Grid = new egret.Rectangle(17,46,5,5);
		t.source = "chat-left-bg_png";
		t.x = 69;
		t.y = 0;
		return t;
	};
	_proto.chatLabel_i = function () {
		var t = new eui.Label();
		this.chatLabel = t;
		t.height = 60;
		t.lineSpacing = 34;
		t.size = 20;
		t.x = 90;
		t.y = 22;
		return t;
	};
	return chatlistIRSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/discardStatusSkin.exml'] = window.discardStatusSkin = (function (_super) {
	__extends(discardStatusSkin, _super);
	var discardStatusSkin$Skin36 = 	(function (_super) {
		__extends(discardStatusSkin$Skin36, _super);
		function discardStatusSkin$Skin36() {
			_super.call(this);
			this.skinParts = [];
			
			this.minHeight = 50;
			this.minWidth = 100;
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","peng_fbtn_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
				,
				new eui.State ("disabledAndSelected",
					[
						new eui.SetProperty("_Image1","source","peng_fbtn_down_png")
					])
			];
		}
		var _proto = discardStatusSkin$Skin36.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "peng_fbtn_png";
			return t;
		};
		return discardStatusSkin$Skin36;
	})(eui.Skin);

	var discardStatusSkin$Skin37 = 	(function (_super) {
		__extends(discardStatusSkin$Skin37, _super);
		function discardStatusSkin$Skin37() {
			_super.call(this);
			this.skinParts = [];
			
			this.minHeight = 50;
			this.minWidth = 100;
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","gang_fbtn_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
				,
				new eui.State ("disabledAndSelected",
					[
						new eui.SetProperty("_Image1","source","gang_fbtn_down_png")
					])
			];
		}
		var _proto = discardStatusSkin$Skin37.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "gang_fbtn_png";
			return t;
		};
		return discardStatusSkin$Skin37;
	})(eui.Skin);

	var discardStatusSkin$Skin38 = 	(function (_super) {
		__extends(discardStatusSkin$Skin38, _super);
		function discardStatusSkin$Skin38() {
			_super.call(this);
			this.skinParts = [];
			
			this.minHeight = 50;
			this.minWidth = 100;
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","chi_fbtn_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
				,
				new eui.State ("disabledAndSelected",
					[
						new eui.SetProperty("_Image1","source","chi_fbtn_down_png")
					])
			];
		}
		var _proto = discardStatusSkin$Skin38.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "chi_fbtn_png";
			return t;
		};
		return discardStatusSkin$Skin38;
	})(eui.Skin);

	var discardStatusSkin$Skin39 = 	(function (_super) {
		__extends(discardStatusSkin$Skin39, _super);
		function discardStatusSkin$Skin39() {
			_super.call(this);
			this.skinParts = [];
			
			this.minHeight = 50;
			this.minWidth = 100;
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","hu_fbtn_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
				,
				new eui.State ("disabledAndSelected",
					[
						new eui.SetProperty("_Image1","source","hu_fbtn_down_png")
					])
			];
		}
		var _proto = discardStatusSkin$Skin39.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "hu_fbtn_png";
			return t;
		};
		return discardStatusSkin$Skin39;
	})(eui.Skin);

	var discardStatusSkin$Skin40 = 	(function (_super) {
		__extends(discardStatusSkin$Skin40, _super);
		function discardStatusSkin$Skin40() {
			_super.call(this);
			this.skinParts = [];
			
			this.minHeight = 50;
			this.minWidth = 100;
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","guo_fbtn_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
				,
				new eui.State ("disabledAndSelected",
					[
						new eui.SetProperty("_Image1","source","guo_fbtn_down_png")
					])
			];
		}
		var _proto = discardStatusSkin$Skin40.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.source = "guo_fbtn_png";
			return t;
		};
		return discardStatusSkin$Skin40;
	})(eui.Skin);

	function discardStatusSkin() {
		_super.call(this);
		this.skinParts = ["_peng","_gang","_chi","_hu","_guo"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._peng_i(),this._gang_i(),this._chi_i(),this._hu_i(),this._guo_i()];
	}
	var _proto = discardStatusSkin.prototype;

	_proto._peng_i = function () {
		var t = new eui.ToggleButton();
		this._peng = t;
		t.x = 702;
		t.y = 494;
		t.skinName = discardStatusSkin$Skin36;
		return t;
	};
	_proto._gang_i = function () {
		var t = new eui.ToggleButton();
		this._gang = t;
		t.x = 817;
		t.y = 494;
		t.skinName = discardStatusSkin$Skin37;
		return t;
	};
	_proto._chi_i = function () {
		var t = new eui.ToggleButton();
		this._chi = t;
		t.x = 932;
		t.y = 494;
		t.skinName = discardStatusSkin$Skin38;
		return t;
	};
	_proto._hu_i = function () {
		var t = new eui.ToggleButton();
		this._hu = t;
		t.x = 1047;
		t.y = 494;
		t.skinName = discardStatusSkin$Skin39;
		return t;
	};
	_proto._guo_i = function () {
		var t = new eui.ToggleButton();
		this._guo = t;
		t.x = 1187;
		t.y = 494;
		t.skinName = discardStatusSkin$Skin40;
		return t;
	};
	return discardStatusSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/gameOverIRSkin.exml'] = window.gameOverIRSkin = (function (_super) {
	__extends(gameOverIRSkin, _super);
	function gameOverIRSkin() {
		_super.call(this);
		this.skinParts = ["_icon","_name","_res","_num"];
		
		this.width = 754;
		this.elementsContent = [this._icon_i(),this._name_i(),this._Image1_i(),this._res_i(),this._num_i()];
	}
	var _proto = gameOverIRSkin.prototype;

	_proto._icon_i = function () {
		var t = new eui.Image();
		this._icon = t;
		t.source = "head-i-2_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._name_i = function () {
		var t = new eui.Label();
		this._name = t;
		t.text = "阿静";
		t.x = 85;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "bei_img_png";
		t.x = 86;
		t.y = 39;
		return t;
	};
	_proto._res_i = function () {
		var t = new eui.Label();
		this._res = t;
		t.text = "x1";
		t.x = 116;
		t.y = 37;
		return t;
	};
	_proto._num_i = function () {
		var t = new eui.Label();
		this._num = t;
		t.size = 50;
		t.text = "+18";
		t.textColor = 0xdd6316;
		t.x = 669;
		t.y = 10;
		return t;
	};
	return gameOverIRSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/gameOverSkin.exml'] = window.gameOverSkin = (function (_super) {
	__extends(gameOverSkin, _super);
	var gameOverSkin$Skin41 = 	(function (_super) {
		__extends(gameOverSkin$Skin41, _super);
		function gameOverSkin$Skin41() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gameOverSkin$Skin41.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "enterroom-btn_png";
			t.verticalCenter = 0;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.text = "返回";
			t.x = 122;
			t.y = 34;
			return t;
		};
		return gameOverSkin$Skin41;
	})(eui.Skin);

	function gameOverSkin() {
		_super.call(this);
		this.skinParts = ["_bg","_title","_back"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._bg_i(),this._title_i(),this._back_i()];
	}
	var _proto = gameOverSkin.prototype;

	_proto._bg_i = function () {
		var t = new eui.Image();
		this._bg = t;
		t.source = "ying_gameover_bg_jpg";
		return t;
	};
	_proto._title_i = function () {
		var t = new eui.Label();
		this._title = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bold = true;
		t.border = true;
		t.borderColor = 0x161313;
		t.height = 62;
		t.italic = true;
		t.size = 60;
		t.text = "碰碰胡";
		t.textAlign = "center";
		t.textColor = 0xf2dcdc;
		t.width = 344;
		t.x = 667;
		t.y = 130;
		return t;
	};
	_proto._back_i = function () {
		var t = new eui.Button();
		this._back = t;
		t.anchorOffsetX = 166;
		t.anchorOffsetY = 48;
		t.x = 876;
		t.y = 690;
		t.skinName = gameOverSkin$Skin41;
		return t;
	};
	return gameOverSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/gameSkin.exml'] = window.gameSkin = (function (_super) {
	__extends(gameSkin, _super);
	var gameSkin$Skin42 = 	(function (_super) {
		__extends(gameSkin$Skin42, _super);
		function gameSkin$Skin42() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gameSkin$Skin42.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "chongzhi_btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return gameSkin$Skin42;
	})(eui.Skin);

	var gameSkin$Skin43 = 	(function (_super) {
		__extends(gameSkin$Skin43, _super);
		function gameSkin$Skin43() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gameSkin$Skin43.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "setting_btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return gameSkin$Skin43;
	})(eui.Skin);

	var gameSkin$Skin44 = 	(function (_super) {
		__extends(gameSkin$Skin44, _super);
		function gameSkin$Skin44() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gameSkin$Skin44.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "liaotian_btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return gameSkin$Skin44;
	})(eui.Skin);

	var gameSkin$Skin45 = 	(function (_super) {
		__extends(gameSkin$Skin45, _super);
		function gameSkin$Skin45() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gameSkin$Skin45.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "daoju_btn_png";
			t.verticalCenter = 0;
			return t;
		};
		return gameSkin$Skin45;
	})(eui.Skin);

	var gameSkin$Skin46 = 	(function (_super) {
		__extends(gameSkin$Skin46, _super);
		function gameSkin$Skin46() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100)
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gameSkin$Skin46.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "yellow_btn_down_png";
			t.verticalCenter = 0;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.size = 20;
			t.text = "开始游戏";
			t.x = 90;
			t.y = 40;
			return t;
		};
		return gameSkin$Skin46;
	})(eui.Skin);

	var gameSkin$Skin47 = 	(function (_super) {
		__extends(gameSkin$Skin47, _super);
		function gameSkin$Skin47() {
			_super.call(this);
			this.skinParts = ["_readyText"];
			
			this.elementsContent = [this._Image1_i(),this._readyText_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","yellow_btn_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gameSkin$Skin47.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "yellow_btn_png";
			t.verticalCenter = 0;
			return t;
		};
		_proto._readyText_i = function () {
			var t = new eui.Label();
			this._readyText = t;
			t.size = 20;
			t.text = "准备";
			t.textAlign = "center";
			t.x = 109.5;
			t.y = 38.5;
			return t;
		};
		return gameSkin$Skin47;
	})(eui.Skin);

	var gameSkin$Skin48 = 	(function (_super) {
		__extends(gameSkin$Skin48, _super);
		function gameSkin$Skin48() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i(),this._Label1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","yellow_btn_down_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gameSkin$Skin48.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "yellow_btn_png";
			t.verticalCenter = 0;
			return t;
		};
		_proto._Label1_i = function () {
			var t = new eui.Label();
			t.size = 20;
			t.text = "邀请";
			t.textAlign = "center";
			t.x = 109.5;
			t.y = 38.5;
			return t;
		};
		return gameSkin$Skin48;
	})(eui.Skin);

	var gameSkin$Skin49 = 	(function (_super) {
		__extends(gameSkin$Skin49, _super);
		function gameSkin$Skin49() {
			_super.call(this);
			this.skinParts = [];
			
			this.elementsContent = [this._Image1_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","percentWidth",100),
						new eui.SetProperty("_Image1","percentHeight",100),
						new eui.SetProperty("_Image1","source","cloase_down_png")
					])
				,
				new eui.State ("disabled",
					[
						new eui.SetProperty("_Image1","source","cloase_down_png")
					])
			];
		}
		var _proto = gameSkin$Skin49.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.horizontalCenter = 0;
			t.source = "close_png";
			t.verticalCenter = 0;
			return t;
		};
		return gameSkin$Skin49;
	})(eui.Skin);

	function gameSkin() {
		_super.call(this);
		this.skinParts = ["_zj2","_zj3","_zj1","_zj4","_count","chongzhi","_setting","_chat","_useTool","_start","_ready","_invest","_back"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._Image1_i(),this._zj2_i(),this._zj3_i(),this._zj1_i(),this._zj4_i(),this._count_i(),this._Image2_i(),this._Image3_i(),this.chongzhi_i(),this._setting_i(),this._chat_i(),this._useTool_i(),this._start_i(),this._ready_i(),this._invest_i(),this._back_i()];
	}
	var _proto = gameSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "jishi_img_png";
		t.x = 613;
		t.y = 290;
		return t;
	};
	_proto._zj2_i = function () {
		var t = new eui.Image();
		this._zj2 = t;
		t.source = "bei_zhongjian_png";
		t.x = 613;
		t.y = 290;
		return t;
	};
	_proto._zj3_i = function () {
		var t = new eui.Image();
		this._zj3 = t;
		t.source = "dong_zhongjian_png";
		t.x = 613;
		t.y = 290;
		return t;
	};
	_proto._zj1_i = function () {
		var t = new eui.Image();
		this._zj1 = t;
		t.source = "xi_zhongjian_png";
		t.x = 613;
		t.y = 290;
		return t;
	};
	_proto._zj4_i = function () {
		var t = new eui.Image();
		this._zj4 = t;
		t.source = "nan_zhongjian_png";
		t.x = 613;
		t.y = 290;
		return t;
	};
	_proto._count_i = function () {
		var t = new eui.Label();
		this._count = t;
		t.size = 25;
		t.textAlign = "center";
		t.width = 28;
		t.x = 658;
		t.y = 333;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "zhuangshi_img_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.scaleX = -1;
		t.source = "zhuangshi_img_png";
		t.x = 1334;
		t.y = 0;
		return t;
	};
	_proto.chongzhi_i = function () {
		var t = new eui.Button();
		this.chongzhi = t;
		t.x = 1118;
		t.y = 7;
		t.skinName = gameSkin$Skin42;
		return t;
	};
	_proto._setting_i = function () {
		var t = new eui.Button();
		this._setting = t;
		t.x = 1205;
		t.y = 7;
		t.skinName = gameSkin$Skin43;
		return t;
	};
	_proto._chat_i = function () {
		var t = new eui.Button();
		this._chat = t;
		t.x = 1222;
		t.y = 633;
		t.skinName = gameSkin$Skin44;
		return t;
	};
	_proto._useTool_i = function () {
		var t = new eui.Button();
		this._useTool = t;
		t.x = 1222;
		t.y = 533;
		t.skinName = gameSkin$Skin45;
		return t;
	};
	_proto._start_i = function () {
		var t = new eui.Button();
		this._start = t;
		t.x = 545.5;
		t.y = 455;
		t.skinName = gameSkin$Skin46;
		return t;
	};
	_proto._ready_i = function () {
		var t = new eui.Button();
		this._ready = t;
		t.x = 546;
		t.y = 550;
		t.skinName = gameSkin$Skin47;
		return t;
	};
	_proto._invest_i = function () {
		var t = new eui.Button();
		this._invest = t;
		t.x = 546;
		t.y = 642;
		t.skinName = gameSkin$Skin48;
		return t;
	};
	_proto._back_i = function () {
		var t = new eui.Button();
		this._back = t;
		t.x = 0;
		t.y = 0;
		t.skinName = gameSkin$Skin49;
		return t;
	};
	return gameSkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/headIcon1.exml'] = window.headIcon1 = (function (_super) {
	__extends(headIcon1, _super);
	function headIcon1() {
		_super.call(this);
		this.skinParts = ["_icon","_name","_id"];
		
		this.height = 70;
		this.elementsContent = [this._Image1_i(),this._icon_i(),this._name_i(),this._id_i()];
	}
	var _proto = headIcon1.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "touxiang_bg_png";
		return t;
	};
	_proto._icon_i = function () {
		var t = new eui.Image();
		this._icon = t;
		t.height = 70;
		t.source = "head-i-2_png";
		t.width = 70;
		return t;
	};
	_proto._name_i = function () {
		var t = new eui.Label();
		this._name = t;
		t.x = 82;
		t.y = 3;
		return t;
	};
	_proto._id_i = function () {
		var t = new eui.Label();
		this._id = t;
		t.x = 81;
		t.y = 37;
		return t;
	};
	return headIcon1;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/headIcon2.exml'] = window.headIcon2 = (function (_super) {
	__extends(headIcon2, _super);
	function headIcon2() {
		_super.call(this);
		this.skinParts = ["_icon","_count"];
		
		this.elementsContent = [this._icon_i(),this._Image1_i(),this._count_i()];
	}
	var _proto = headIcon2.prototype;

	_proto._icon_i = function () {
		var t = new eui.Image();
		this._icon = t;
		t.height = 70;
		t.source = "head-i-2_png";
		t.width = 70;
		t.x = 4;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "fenshu_bg_png";
		t.y = 74;
		return t;
	};
	_proto._count_i = function () {
		var t = new eui.Label();
		this._count = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 13;
		t.size = 13;
		t.text = "Label";
		t.textAlign = "center";
		t.width = 71;
		t.x = 4;
		t.y = 79;
		return t;
	};
	return headIcon2;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/toolIRUISkin.exml'] = window.toolIRUISkin = (function (_super) {
	__extends(toolIRUISkin, _super);
	function toolIRUISkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 86;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Label1_i()];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data.bg"],[0],this._Image1,"source")
		eui.Binding.$bindProperties(this, ["hostComponent.data.icon"],[0],this._Image2,"source")
		eui.Binding.$bindProperties(this, ["hostComponent.data.count"],[0],this._Label1,"text")
	}
	var _proto = toolIRUISkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		this._Label1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fontFamily = "微软雅黑";
		t.height = 23;
		t.size = 15;
		t.textAlign = "left";
		t.verticalAlign = "middle";
		t.width = 20;
		t.x = 67;
		t.y = 63;
		return t;
	};
	return toolIRUISkin;
})(eui.Skin);generateEUI.paths['resource/eui_game/skins/useToolSkin.exml'] = window.usetoolSkin = (function (_super) {
	__extends(usetoolSkin, _super);
	function usetoolSkin() {
		_super.call(this);
		this.skinParts = ["_useToolBg","ownTools","scrListFriend"];
		
		this.height = 750;
		this.width = 1334;
		this.elementsContent = [this._useToolBg_i(),this.scrListFriend_i()];
	}
	var _proto = usetoolSkin.prototype;

	_proto._useToolBg_i = function () {
		var t = new eui.Image();
		this._useToolBg = t;
		t.alpha = 0.5;
		t.percentHeight = 100;
		t.source = "usetool-bg_png";
		t.touchEnabled = true;
		t.percentWidth = 100;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.scrListFriend_i = function () {
		var t = new eui.Scroller();
		this.scrListFriend = t;
		t.height = 100;
		t.percentWidth = 70;
		t.x = 350;
		t.y = 630;
		t.viewport = this.ownTools_i();
		return t;
	};
	_proto.ownTools_i = function () {
		var t = new eui.List();
		this.ownTools = t;
		t.height = 92;
		t.width = 315;
		t.x = -71;
		t.y = 413;
		t.layout = this._HorizontalLayout1_i();
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		return t;
	};
	return usetoolSkin;
})(eui.Skin);